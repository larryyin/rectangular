# -*- coding: utf-8 -*-
import time
run_start = time.time()

import numpy as np
import pandas as pd
#import matplotlib.pyplot as plt
import os
import shutil
import scipy.ndimage as ndimage

#%%
def makeNewDIR(DIR):
    if not os.path.exists(DIR):
        os.makedirs(DIR)
    else:
        shutil.rmtree(DIR)
        os.makedirs(DIR)

def _det(xvert, yvert):
    '''Compute twice the area of the triangle defined by points with using
    determinant formula.

    Input parameters:

    xvert -- A vector of nodal x-coords (array-like).
    yvert -- A vector of nodal y-coords (array-like).

    Output parameters:

    Twice the area of the triangle defined by the points.

    Notes:

    _det is positive if points define polygon in anticlockwise order.
    _det is negative if points define polygon in clockwise order.
    _det is zero if at least two of the points are concident or if
        all points are collinear.

    '''
    xvert = np.asfarray(xvert)
    yvert = np.asfarray(yvert)
    x_prev = np.concatenate(([xvert[-1]], xvert[:-1]))
    y_prev = np.concatenate(([yvert[-1]], yvert[:-1]))
    return np.sum(yvert * x_prev - xvert * y_prev, axis=0)

class Polygon:
    '''Polygon object.

    Input parameters:

    x -- A sequence of nodal x-coords.
    y -- A sequence of nodal y-coords.

    '''

    def __init__(self, x, y):
        if len(x) != len(y):
            raise IndexError('x and y must be equally sized.')
        self.x = np.asfarray(x)
        self.y = np.asfarray(y)
        # Closes the polygon if were open
        x1, y1 = x[0], y[0]
        xn, yn = x[-1], y[-1]
        if x1 != xn or y1 != yn:
            self.x = np.concatenate((self.x, [x1]))
            self.y = np.concatenate((self.y, [y1]))
        # Anti-clockwise coordinates
        if _det(self.x, self.y) < 0:
            self.x = self.x[::-1]
            self.y = self.y[::-1]

    def is_inside(self, xpoint, ypoint, smalld=1e-12):
        '''Check if point is inside a general polygon.

        Input parameters:

        xpoint -- The x-coord of the point to be tested.
        ypoint -- The y-coords of the point to be tested.
        smalld -- A small float number.

        xpoint and ypoint could be scalars or array-like sequences.

        Output parameters:

        mindst -- The distance from the point to the nearest point of the
                  polygon.
                  If mindst < 0 then point is outside the polygon.
                  If mindst = 0 then point in on a side of the polygon.
                  If mindst > 0 then point is inside the polygon.

        Notes:

        An improved version of the algorithm of Nordbeck and Rydstedt.

        REF: SLOAN, S.W. (1985): A point-in-polygon program. Adv. Eng.
             Software, Vol 7, No. 1, pp 45-47.

        '''
        xpoint = np.asfarray(xpoint)
        ypoint = np.asfarray(ypoint)
        # Scalar to array
        if xpoint.shape is tuple():
            xpoint = np.array([xpoint], dtype=float)
            ypoint = np.array([ypoint], dtype=float)
            scalar = True
        else:
            scalar = False
        # Check consistency
        if xpoint.shape != ypoint.shape:
            raise IndexError('x and y has different shapes')
        # If snear = True: Dist to nearest side < nearest vertex
        # If snear = False: Dist to nearest vertex < nearest side
        snear = np.ma.masked_all(xpoint.shape, dtype=bool)
        # Initialize arrays
        mindst = np.ones_like(xpoint, dtype=float) * np.inf
        j = np.ma.masked_all(xpoint.shape, dtype=int)
        x = self.x
        y = self.y
        n = len(x) - 1  # Number of sides/vertices defining the polygon
        # Loop over each side defining polygon
        for i in range(n):
            d = np.ones_like(xpoint, dtype=float) * np.inf
            # Start of side has coords (x1, y1)
            # End of side has coords (x2, y2)
            # Point has coords (xpoint, ypoint)
            x1 = x[i]
            y1 = y[i]
            x21 = x[i + 1] - x1
            y21 = y[i + 1] - y1
            x1p = x1 - xpoint
            y1p = y1 - ypoint
            # Points on infinite line defined by
            #     x = x1 + t * (x1 - x2)
            #     y = y1 + t * (y1 - y2)
            # where
            #     t = 0    at (x1, y1)
            #     t = 1    at (x2, y2)
            # Find where normal passing through (xpoint, ypoint) intersects
            # infinite line
            t = -(x1p * x21 + y1p * y21) / (x21 ** 2 + y21 ** 2)
            tlt0 = t < 0
            tle1 = (0 <= t) & (t <= 1)
            # Normal intersects side
            d[tle1] = ((x1p[tle1] + t[tle1] * x21) ** 2 +
                       (y1p[tle1] + t[tle1] * y21) ** 2)
            # Normal does not intersects side
            # Point is closest to vertex (x1, y1)
            # Compute square of distance to this vertex
            d[tlt0] = x1p[tlt0] ** 2 + y1p[tlt0] ** 2
            # Store distances
            mask = d < mindst
            mindst[mask] = d[mask]
            j[mask] = i
            # Point is closer to (x1, y1) than any other vertex or side
            snear[mask & tlt0] = False
            # Point is closer to this side than to any other side or vertex
            snear[mask & tle1] = True
        if np.ma.count(snear) != snear.size:
            raise IndexError('Error computing distances')
        mindst **= 0.5
        # Point is closer to its nearest vertex than its nearest side, check if
        # nearest vertex is concave.
        # If the nearest vertex is concave then point is inside the polygon,
        # else the point is outside the polygon.
        jo = j.copy()
        jo[j == 0] -= 1
        area = _det([x[j + 1], x[j], x[jo - 1]], [y[j + 1], y[j], y[jo - 1]])
        mindst[~snear] = np.copysign(mindst, area)[~snear]
        # Point is closer to its nearest side than to its nearest vertex, check
        # if point is to left or right of this side.
        # If point is to left of side it is inside polygon, else point is
        # outside polygon.
        area = _det([x[j], x[j + 1], xpoint], [y[j], y[j + 1], ypoint])
        mindst[snear] = np.copysign(mindst, area)[snear]
        # Point is on side of polygon
        mindst[np.fabs(mindst) < smalld] = 0
        # If input values were scalar then the output should be too
        if scalar:
            mindst = float(mindst)
        return mindst

# Zoning
def zoning(data_bool,data_raw):
    print('Processing hydraulic connectivity...')
    
    current_output, num_ids = ndimage.label(data_bool)
    
    # Plot outputs
    #plt.imshow(data_bool, cmap="spectral", interpolation='nearest')
    #plt.imshow(current_output, cmap="spectral", interpolation='nearest')
    
    zone_id = range(num_ids+1)
    zone_count = []
    zone_mean = []
    zone_min = []
    for i in zone_id:
        zone = current_output==i
        zone_count.append(np.sum(zone))
        zone_mean.append(np.nanmean(data_raw[zone]))
        zone_min.append(np.nanmin(data_raw[zone]))
    
    Z = pd.DataFrame({'Count':zone_count,
                      'Mean':zone_mean,
                      'Min':zone_min},
                     index=zone_id)
    
#    inun_id = Z.sort_values('Min').index[0]
    inun_id = (Z.Count.rank(ascending=True)*2+Z.Mean.rank(ascending=False)*2+Z.Min.rank(ascending=False)*3).idxmax()
    inun_zone = current_output==inun_id
    inun = np.zeros(data_raw.shape)
    inun[inun_zone] = 1
    inun = inun.astype(bool)
    return inun

#%%
S = np.load('bin.npz')
cnI=int(S['cnI'])
cnJ=int(S['cnJ'])
Im=S['Im']
Jm=S['Jm']
H1m=S['H1m']
H2m=S['H2m']
depthm=S['depthm']
ANGm=S['ANGm']
latm=S['latm']
lonm=S['lonm']
datumm=S['datumm']
nlcdm=S['nlcdm']
manm=S['manm']
#cn_latm=S['cn_latm']
#cn_lonm=S['cn_lonm']
S = None


#%% Modify
M = pd.read_csv('mod_1.csv').drop_duplicates(['lon','lat'])
P = Polygon(M.lon.values,M.lat.values)
Pm = P.is_inside(lonm,latm)>0
depthm[np.logical_and(Pm,np.logical_or(depthm<5,np.isnan(depthm)))] = 5
nlcdm[Pm] = 11
manm[Pm] = 0.02



#%% Drain
# def
drainm_def = (depthm.round(decimals=2)<0).astype(int)
# hyd
land_bool = (depthm.round(decimals=2)>=0).astype(int)
land_bool[np.isnan(land_bool)] = 0
drainm = (~zoning(land_bool, -depthm)).astype(int)

waterm = (~ drainm.astype(bool)).astype(int)

drainm_def = drainm_def.astype(float)
drainm = drainm.astype(float)
drainm_def[drainm_def==0] = 0.00145
drainm[drainm==0] = 0.00145



#%%
#plt.imshow(depthm);plt.colorbar()
#plt.show()
#plt.close()
#plt.imshow(manm);plt.colorbar()
#plt.show()
#plt.close()

#%% Output
outPath = 'base_modify/'
makeNewDIR(outPath)

print('Write to output...')

## Write to model_grid_hor
#s = []
#s += "Horizontal Segmentations\n"
#s += "{nI:5d}{nJ:5d}".format(nI=cnI,nJ=cnJ)
#for j in range(1,cnJ-1):
#    for i in range(1,cnI-1):
#        if ~np.isnan(depthm[i][j]):
#            s += "\n{I:5d}{J:5d}{H1:10.2f}{H2:10.2f}{depth:10.3f}{ang:10.2f}{lat:10.6f}{lon:10.6f}{datum:5.1f}".format(I=Im[i][j],J=Jm[i][j],H1=H1m[i][j],H2=H2m[i][j],depth=depthm[i][j],ang=ANGm[i][j],lat=latm[i][j],lon=lonm[i][j],datum=datumm[i][j])  
#with open(outPath+'model_grid_hor', 'w') as f:
#    f.writelines(s)
#
## Write to bfric2d.inp
#BFRIC_base = 0.0025
#s = []
#s += "NVARBF    BFRIC\n"
#s += "   -1{base:10.5f}\n".format(base=BFRIC_base)
#s += "    I    J     VARBF"
#for j in range(cnJ):
#    for i in range(cnI):
#        s += "\n{I:5d}{J:5d}{Man:10.5f}".format(I=i+1,J=j+1,Man=manm[i][j])  
#with open(outPath+'bfric2d.inp', 'w') as f:
#    f.writelines(s)

# Write model_grid and NLCD/Manning's to csv
# NLCD to Manning's
LC = pd.read_csv('../nlcd_table.csv')
LC_match = list(zip(LC.NLCD.values,LC.Manning.values))
LC_dict = dict(zip(LC.NLCD.values,LC.Name.values))

s = []
s += "I,J,H1,H2,depth,dem,ang,lat,lon,datum,NLCD,Mannings,Land,NLCD_raw,Man_raw,Land_raw,water,drain,drain_hyd,drain_def,build"
for j in range(1,cnJ-1):
    for i in range(1,cnI-1):
        if ~np.isnan(depthm[i][j]):
            s += "\n{I:d},{J:d},{H1:.2f},{H2:.2f},{depth:.3f},{dem:.3f},{ang:.2f},{lat:.6f},{lon:.6f},{datum:.1f},{NLCD:.0f},{Mannings:.3f},{Land:s},{NLCD_raw:.0f},{Man_raw:.3f},{Land_raw:s},{Water:.0f},{Drain:.5f},{Drain_hyd:.5f},{Drain_def:.5f},{Build:.0f}".format(I=Im[i][j],J=Jm[i][j],H1=H1m[i][j],H2=H2m[i][j],depth=depthm[i][j],dem=depthm[i][j],ang=ANGm[i][j],lat=latm[i][j],lon=lonm[i][j],datum=datumm[i][j],NLCD=nlcdm[i][j],Mannings=manm[i][j],Land=LC_dict[int(nlcdm[i][j])],NLCD_raw=nlcdm[i][j],Man_raw=manm[i][j],Land_raw=LC_dict[int(nlcdm[i][j])],Water=waterm[i][j],Drain=drainm[i][j],Drain_hyd=drainm[i][j],Drain_def=drainm_def[i][j],Build=0)  
with open(outPath+'model_grid_base.csv', 'w') as f:
    f.writelines(s)

#s = []
#s += "    I    J    drain_mask"
#for j in range(1,cnJ-1):
#    for i in range(1,cnI-1):
#        if ~np.isnan(depthm[i][j]):
#            s += "\n{I:5d}{J:5d}{Drain:5d}".format(I=Im[i][j],J=Jm[i][j],Drain=drainm[i][j])  
#with open(outPath+'drain_mask', 'w') as f:
#    f.writelines(s)


# Save to binary
#np.savez(outPath+'bin.npz', 
#     cnI=cnI,cnJ=cnJ,Im=Im,Jm=Jm,H1m=H1m,H2m=H2m,depthm=depthm,
#     ANGm=ANGm,latm=latm,lonm=lonm,datumm=datumm,nlcdm=nlcdm,manm=manm)

#np.savez(outPath+'bin.npz', 
#     cnI=cnI,cnJ=cnJ,Im=Im,Jm=Jm,H1m=H1m,H2m=H2m,depthm=depthm,
#     ANGm=ANGm,latm=latm,lonm=lonm,datumm=datumm,nlcdm=nlcdm,manm=manm,
#     cn_latm=cn_latm,cn_lonm=cn_lonm)

#%%
#%% Stats
#stats_node = cnI*cnJ
#stats_area = np.nansum((H1m*H2m).ravel())
#
#stats_dt1 = np.nanmin((0.5*H1m/np.sqrt(9.80665*(depthm+3))).ravel())
#stats_dt2 = np.nanmin((0.5*H2m/np.sqrt(9.80665*(depthm+3))).ravel())
#
#stats_lon_max = np.nanmax(lonm.ravel())
#stats_lon_min = np.nanmin(lonm.ravel())
#stats_lat_max = np.nanmax(latm.ravel())
#stats_lat_min = np.nanmin(latm.ravel())
#
#stats_H1_mean = np.nanmean(H1m.ravel())
#stats_H1_median = np.nanmedian(H1m.ravel())
#stats_H1_max = np.nanmax(H1m.ravel())
#stats_H1_min = np.nanmin(H1m.ravel())
#stats_H2_mean = np.nanmean(H2m.ravel())
#stats_H2_median = np.nanmedian(H2m.ravel())
#stats_H2_max = np.nanmax(H2m.ravel())
#stats_H2_min = np.nanmin(H2m.ravel())
#stats_ANG_mean = np.nanmean(ANGm.ravel())
#stats_ANG_median = np.nanmedian(ANGm.ravel())
#stats_ANG_max = np.nanmax(ANGm.ravel())
#stats_ANG_min = np.nanmin(ANGm.ravel())
#stats_depth_mean = np.nanmean(depthm.ravel())
#stats_depth_median = np.nanmedian(depthm.ravel())
#stats_depth_max = np.nanmax(depthm.ravel())
#stats_depth_min = np.nanmin(depthm.ravel())
#
## Write to stats.txt
#s=[]
#s+='Stats\n'
#s+='Nodes: {:d} x {:d} = {:d}\n'.format(cnI,cnJ,stats_node)
#s+='Extent: {:.6f}, {:.6f}, {:.6f}, {:.6f}\n'.format(stats_lon_min,stats_lat_min,stats_lon_max,stats_lat_max)
#s+='Area: {:.2f} m^2\n'.format(stats_area)
#s+='H1: mean({:.2f}), median({:.2f}), min({:.2f}), max({:.2f})\n'.format(stats_H1_mean,stats_H1_median,stats_H1_min,stats_H1_max)
#s+='H2: mean({:.2f}), median({:.2f}), min({:.2f}), max({:.2f})\n'.format(stats_H2_mean,stats_H2_median,stats_H2_min,stats_H2_max)
#s+='ANG: mean({:.2f}), median({:.2f}), min({:.2f}), max({:.2f})\n'.format(stats_ANG_mean,stats_ANG_median,stats_ANG_min,stats_ANG_max)
#s+='Depth: mean({:.3f}), median({:.3f}), min({:.3f}), max({:.3f})\n'.format(stats_depth_mean,stats_depth_median,stats_depth_min,stats_depth_max)
#s+='Min time step along I: {:.3f} s\n'.format(stats_dt1)
#s+='Min time step along J: {:.3f} s\n'.format(stats_dt2)
#with open(outPath+'stats.txt', 'w') as f:
#    f.writelines(s)

run_end = time.time()
print(run_end-run_start)