# -*- coding: utf-8 -*-
import time
run_start = time.time()

import numpy as np
import pandas as pd
#import matplotlib.pyplot as plt
import os
import shutil

#%%
def makeNewDIR(DIR):
    if not os.path.exists(DIR):
        os.makedirs(DIR)
    else:
        shutil.rmtree(DIR)
        os.makedirs(DIR)

#%% Output
outPath = 'build_final/'
makeNewDIR(outPath)

#%%
S = np.load('bin.npz')
cnI=int(S['cnI'])
cnJ=int(S['cnJ'])
#Im=S['Im']
#Jm=S['Jm']
#H1m=S['H1m']
#H2m=S['H2m']
#depthm=S['depthm']
#ANGm=S['ANGm']
#latm=S['latm']
#lonm=S['lonm']
#datumm=S['datumm']
#nlcdm=S['nlcdm']
manm=S['manm']
#cn_latm=S['cn_latm']
#cn_lonm=S['cn_lonm']
S = None
#
G = pd.read_csv('model_grid_build_final.csv')
Is = G.I.values
Js = G.J.values
H1s = G.H1.values
H2s = G.H2.values
depths = G.depth.values
angs = G.ang.values
lats = G.lat.values
lons = G.lon.values
datums = G.datum.values
NLCDs = G.NLCD.values
Mannings = G.Mannings.values
Lands = G.Land.values
drains = G.drain.values
buildings = G.build.values
waters = G.water.values

#%%
BFRIC_base = 0.0025
DRAIN_base = 4

#%%
print('Write to output...')

# Write to model_grid_hor
s = []
s += "Horizontal Segmentations\n"
s += "{nI:5d}{nJ:5d}".format(nI=cnI,nJ=cnJ)
for i in range(len(G)):
    s += "\n{I:5d}{J:5d}{H1:10.2f}{H2:10.2f}{depth:10.3f}{ang:10.2f}{lat:10.6f}{lon:10.6f}{datum:5.1f}".format(I=Is[i],J=Js[i],H1=H1s[i],H2=H2s[i],depth=depths[i],ang=angs[i],lat=lats[i],lon=lons[i],datum=datums[i])  
with open(outPath+'model_grid_hor', 'w') as f:
    f.writelines(s)


# Write to drain_mask
s = []
s += "BASE_DRAIN_RATE (cm/hr)"
s += "\n{:10.5f}".format(DRAIN_base)
s += "\n    I    J    drain_ratio"
for i in range(len(G)):
    s += "\n{I:5d}{J:5d}{Drain:10.5f}".format(I=Is[i],J=Js[i],Drain=drains[i])  
with open(outPath+'drain_mask', 'w') as f:
    f.writelines(s)


# Write to building_mask
s = []
s += "    I    J    building_mask"
for i in range(len(G)):
    s += "\n{I:5d}{J:5d}{Building:5d}".format(I=Is[i],J=Js[i],Building=buildings[i])  
with open(outPath+'building_mask', 'w') as f:
    f.writelines(s)

# Write to water_mask
s = []
s += "    I    J    water_mask"
for i in range(len(G)):
    s += "\n{I:5d}{J:5d}{Water:5d}".format(I=Is[i],J=Js[i],Water=waters[i])  
with open(outPath+'water_mask', 'w') as f:
    f.writelines(s)

# Write to bfric2d.inp
s = []
s += "NVARBF    BFRIC\n"
s += "   -1{base:10.5f}\n".format(base=BFRIC_base)
s += "    I    J     VARBF"
for i in range(len(G)):
        s += "\n{I:5d}{J:5d}{Man:10.5f}".format(I=Is[i],J=Js[i],Man=Mannings[i])  
with open(outPath+'bfric2d.inp', 'w') as f:
    f.writelines(s)

#%%
print('Calculate stats...')
#%% Stats
stats_node = cnI*cnJ
stats_area = np.nansum(H1s*H2s)

stats_dt_add = 6
stats_dt_valid = depths>-stats_dt_add
stats_dt1 = np.nanmin(0.5*H1s[stats_dt_valid]/np.sqrt(9.80665*np.ceil(depths[stats_dt_valid]+stats_dt_add)))
stats_dt2 = np.nanmin(0.5*H2s[stats_dt_valid]/np.sqrt(9.80665*np.ceil(depths[stats_dt_valid]+stats_dt_add)))

stats_lon_max = np.nanmax(lons)
stats_lon_min = np.nanmin(lons)
stats_lat_max = np.nanmax(lats)
stats_lat_min = np.nanmin(lats)

stats_H1_mean = np.nanmean(H1s)
stats_H1_median = np.nanmedian(H1s)
stats_H1_max = np.nanmax(H1s)
stats_H1_min = np.nanmin(H1s)
stats_H2_mean = np.nanmean(H2s)
stats_H2_median = np.nanmedian(H2s)
stats_H2_max = np.nanmax(H2s)
stats_H2_min = np.nanmin(H2s)
stats_ANG_mean = np.nanmean(angs)
stats_ANG_median = np.nanmedian(angs)
stats_ANG_max = np.nanmax(angs)
stats_ANG_min = np.nanmin(angs)
stats_depth_mean = np.nanmean(depths)
stats_depth_median = np.nanmedian(depths)
stats_depth_max = np.nanmax(depths)
stats_depth_min = np.nanmin(depths)

# Write to stats.txt
s=[]
s+='Stats\n'
s+='Nodes: {:d} x {:d} = {:d}\n'.format(cnI,cnJ,stats_node)
s+='Extent: {:.6f}, {:.6f}, {:.6f}, {:.6f}\n'.format(stats_lon_min,stats_lat_min,stats_lon_max,stats_lat_max)
s+='Area: {:.2f} m^2\n'.format(stats_area)
s+='H1: mean({:.2f}), median({:.2f}), min({:.2f}), max({:.2f})\n'.format(stats_H1_mean,stats_H1_median,stats_H1_min,stats_H1_max)
s+='H2: mean({:.2f}), median({:.2f}), min({:.2f}), max({:.2f})\n'.format(stats_H2_mean,stats_H2_median,stats_H2_min,stats_H2_max)
s+='ANG: mean({:.2f}), median({:.2f}), min({:.2f}), max({:.2f})\n'.format(stats_ANG_mean,stats_ANG_median,stats_ANG_min,stats_ANG_max)
s+='Depth: mean({:.3f}), median({:.3f}), min({:.3f}), max({:.3f})\n'.format(stats_depth_mean,stats_depth_median,stats_depth_min,stats_depth_max)
s+='Min time step along I: {:.3f} s\n'.format(stats_dt1)
s+='Min time step along J: {:.3f} s\n'.format(stats_dt2)
with open(outPath+'stats.txt', 'w') as f:
    f.writelines(s)


#%%
run_end = time.time()
print(run_end-run_start)