#!/usr/bin/env python

#from flask import Flask, jsonify, render_template, request
#app = Flask(__name__)

from osgeo import ogr
from osgeo import osr
from osgeo import gdal
from osgeo.gdalnumeric import *
from osgeo.gdalconst import *
#import json
import numpy as np
import pandas as pd
from scipy.interpolate import griddata
#import os
import re
import shutil
from subprocess import call
#from scipy import stats
import time
import shelve

def center2corners(CENTER):
    CORNERS = np.zeros([CENTER.shape[0]+1,CENTER.shape[1]+1])
    I_diff_half = np.diff(CENTER,axis=0)*.5
    J_diff_half = np.diff(CENTER,axis=1)*.5
    
    I_interim = CENTER[:-1,:]+I_diff_half
    J_interim_diff_half = np.diff(I_interim,axis=1)*.5
    CORNERS[1:-1,1:-1] = I_interim[:,:-1]+J_interim_diff_half
    
    # Sides
    I_W_interim = CENTER[0,:]-I_diff_half[0,:]
    J_W_diff_half = np.diff(I_W_interim)*.5
    CORNERS[0,1:-1] = I_W_interim[:-1]+J_W_diff_half
    
    I_E_interim = CENTER[-1,:]+I_diff_half[-1,:]
    J_E_diff_half = np.diff(I_E_interim)*.5
    CORNERS[-1,1:-1] = I_E_interim[:-1]+J_E_diff_half
    
    I_S_interim = CENTER[:,0]-J_diff_half[:,0]
    J_S_diff_half = np.diff(I_S_interim)*.5
    CORNERS[1:-1,0] = I_S_interim[:-1]+J_S_diff_half
    
    I_N_interim = CENTER[:,-1]+J_diff_half[:,-1]
    J_N_diff_half = np.diff(I_N_interim)*.5
    CORNERS[1:-1,-1] = I_N_interim[:-1]+J_N_diff_half
    
    # Corners
    CORNERS[0,0] = CENTER[0,0]-I_diff_half[0,0]-J_diff_half[0,0]
    CORNERS[-1,0] = CENTER[-1,0]+I_diff_half[-1,0]-J_diff_half[-1,0]
    CORNERS[0,-1] = CENTER[0,-1]-I_diff_half[0,-1]+J_diff_half[0,-1]
    CORNERS[-1,-1] = CENTER[-1,-1]+I_diff_half[-1,-1]+J_diff_half[-1,-1]
    
    return CORNERS

def dist_greatcircle(lat1,lon1,lat2,lon2):
    R = 6371000   # m
    latrad1 = np.deg2rad(lat1)
    latrad2 = np.deg2rad(lat2)
    dLat = latrad2-latrad1
    dLon = np.deg2rad(lon2-lon1)
    a = (np.sin(dLat/2) * np.sin(dLat/2) +
        np.cos(latrad1) * np.cos(latrad2) *
        np.sin(dLon/2) * np.sin(dLon/2))
    c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1-a))
    return R * c

def bearing(lat1,lon1,lat2,lon2):
    latrad1 = np.deg2rad(lat1)
    latrad2 = np.deg2rad(lat2)
    lonrad1 = np.deg2rad(lon1)
    lonrad2 = np.deg2rad(lon2)
    y = np.sin(lonrad2-lonrad1) * np.cos(latrad2)
    x = (np.cos(latrad1)*np.sin(latrad2)-
        np.sin(latrad1)*np.cos(latrad2)*np.cos(lonrad2-lonrad1))
    return np.rad2deg(np.arctan2(y, x))

def latlonlen(latdeg):
    lat = np.deg2rad(latdeg)
    m1 = 111132.92;
    m2 = -559.82;
    m3 = 1.175;
    m4 = -0.0023;
    p1 = 111412.84;
    p2 = -93.5;
    p3 = 0.118;
    latlen = m1+(m2*np.cos(2*lat))+(m3*np.cos(4*lat))+(m4*np.cos(6*lat));
    lonlen = (p1*np.cos(lat))+(p2*np.cos(3*lat))+(p3*np.cos(5*lat));
    return (latlen,lonlen) # m

def _det(xvert, yvert):
    '''Compute twice the area of the triangle defined by points with using
    determinant formula.

    Input parameters:

    xvert -- A vector of nodal x-coords (array-like).
    yvert -- A vector of nodal y-coords (array-like).

    Output parameters:

    Twice the area of the triangle defined by the points.

    Notes:

    _det is positive if points define polygon in anticlockwise order.
    _det is negative if points define polygon in clockwise order.
    _det is zero if at least two of the points are concident or if
        all points are collinear.

    '''
    xvert = np.asfarray(xvert)
    yvert = np.asfarray(yvert)
    x_prev = np.concatenate(([xvert[-1]], xvert[:-1]))
    y_prev = np.concatenate(([yvert[-1]], yvert[:-1]))
    return np.sum(yvert * x_prev - xvert * y_prev, axis=0)

class Polygon:
    '''Polygon object.

    Input parameters:

    x -- A sequence of nodal x-coords.
    y -- A sequence of nodal y-coords.

    '''

    def __init__(self, x, y):
        if len(x) != len(y):
            raise IndexError('x and y must be equally sized.')
        self.x = np.asfarray(x)
        self.y = np.asfarray(y)
        # Closes the polygon if were open
        x1, y1 = x[0], y[0]
        xn, yn = x[-1], y[-1]
        if x1 != xn or y1 != yn:
            self.x = np.concatenate((self.x, [x1]))
            self.y = np.concatenate((self.y, [y1]))
        # Anti-clockwise coordinates
        if _det(self.x, self.y) < 0:
            self.x = self.x[::-1]
            self.y = self.y[::-1]

    def is_inside(self, xpoint, ypoint, smalld=1e-12):
        '''Check if point is inside a general polygon.

        Input parameters:

        xpoint -- The x-coord of the point to be tested.
        ypoint -- The y-coords of the point to be tested.
        smalld -- A small float number.

        xpoint and ypoint could be scalars or array-like sequences.

        Output parameters:

        mindst -- The distance from the point to the nearest point of the
                  polygon.
                  If mindst < 0 then point is outside the polygon.
                  If mindst = 0 then point in on a side of the polygon.
                  If mindst > 0 then point is inside the polygon.

        Notes:

        An improved version of the algorithm of Nordbeck and Rydstedt.

        REF: SLOAN, S.W. (1985): A point-in-polygon program. Adv. Eng.
             Software, Vol 7, No. 1, pp 45-47.

        '''
        xpoint = np.asfarray(xpoint)
        ypoint = np.asfarray(ypoint)
        # Scalar to array
        if xpoint.shape is tuple():
            xpoint = np.array([xpoint], dtype=float)
            ypoint = np.array([ypoint], dtype=float)
            scalar = True
        else:
            scalar = False
        # Check consistency
        if xpoint.shape != ypoint.shape:
            raise IndexError('x and y has different shapes')
        # If snear = True: Dist to nearest side < nearest vertex
        # If snear = False: Dist to nearest vertex < nearest side
        snear = np.ma.masked_all(xpoint.shape, dtype=bool)
        # Initialize arrays
        mindst = np.ones_like(xpoint, dtype=float) * np.inf
        j = np.ma.masked_all(xpoint.shape, dtype=int)
        x = self.x
        y = self.y
        n = len(x) - 1  # Number of sides/vertices defining the polygon
        # Loop over each side defining polygon
        for i in range(n):
            d = np.ones_like(xpoint, dtype=float) * np.inf
            # Start of side has coords (x1, y1)
            # End of side has coords (x2, y2)
            # Point has coords (xpoint, ypoint)
            x1 = x[i]
            y1 = y[i]
            x21 = x[i + 1] - x1
            y21 = y[i + 1] - y1
            x1p = x1 - xpoint
            y1p = y1 - ypoint
            # Points on infinite line defined by
            #     x = x1 + t * (x1 - x2)
            #     y = y1 + t * (y1 - y2)
            # where
            #     t = 0    at (x1, y1)
            #     t = 1    at (x2, y2)
            # Find where normal passing through (xpoint, ypoint) intersects
            # infinite line
            t = -(x1p * x21 + y1p * y21) / (x21 ** 2 + y21 ** 2)
            tlt0 = t < 0
            tle1 = (0 <= t) & (t <= 1)
            # Normal intersects side
            d[tle1] = ((x1p[tle1] + t[tle1] * x21) ** 2 +
                       (y1p[tle1] + t[tle1] * y21) ** 2)
            # Normal does not intersects side
            # Point is closest to vertex (x1, y1)
            # Compute square of distance to this vertex
            d[tlt0] = x1p[tlt0] ** 2 + y1p[tlt0] ** 2
            # Store distances
            mask = d < mindst
            mindst[mask] = d[mask]
            j[mask] = i
            # Point is closer to (x1, y1) than any other vertex or side
            snear[mask & tlt0] = False
            # Point is closer to this side than to any other side or vertex
            snear[mask & tle1] = True
        if np.ma.count(snear) != snear.size:
            raise IndexError('Error computing distances')
        mindst **= 0.5
        # Point is closer to its nearest vertex than its nearest side, check if
        # nearest vertex is concave.
        # If the nearest vertex is concave then point is inside the polygon,
        # else the point is outside the polygon.
        jo = j.copy()
        jo[j == 0] -= 1
        area = _det([x[j + 1], x[j], x[jo - 1]], [y[j + 1], y[j], y[jo - 1]])
        mindst[~snear] = np.copysign(mindst, area)[~snear]
        # Point is closer to its nearest side than to its nearest vertex, check
        # if point is to left or right of this side.
        # If point is to left of side it is inside polygon, else point is
        # outside polygon.
        area = _det([x[j], x[j + 1], xpoint], [y[j], y[j + 1], ypoint])
        mindst[snear] = np.copysign(mindst, area)[snear]
        # Point is on side of polygon
        mindst[np.fabs(mindst) < smalld] = 0
        # If input values were scalar then the output should be too
        if scalar:
            mindst = float(mindst)
        return mindst

def kml2polygon(kml,extentW=None,extentS=None,extentE=None,extentN=None):
    with open(kml,'r') as f_poly:
        text_all = f_poly.read().replace('\n', '')
    
    item = text_all.split("</outerBoundaryIs>")[0]
    if "<outerBoundaryIs>" in item:
        testStr = item[item.find("<outerBoundaryIs>")+len("<outerBoundaryIs>"):]
        if ',0.' not in testStr:
            isNear0 = 0
            if ',0' in testStr:
                is3D = 1
            else:
                is3D = 0
        else:
            isNear0 = 1
            if ',0' in testStr:
                is3D = 1
            else:
                is3D = 0
    
    outer_block = []
    
    if (isNear0==0) and (is3D==1):
        stripper = re.compile(r'[^\d.,-;]+')
        for item in text_all.split("</outerBoundaryIs>"):
            if "<outerBoundaryIs>" in item:
                block = (stripper.sub('', item[item.find("<outerBoundaryIs>")+
                         len("<outerBoundaryIs>"):].replace(',0',';'))).rstrip('/').rstrip(';')
                outer_block.append(block)
    elif (isNear0==1) and (is3D==1):
        stripper = re.compile(r'[^\d.,-;]+')
        for item in text_all.split("</outerBoundaryIs>"):
            if "<outerBoundaryIs>" in item:
                block = (stripper.sub('', item[item.find("<outerBoundaryIs>")+
                         len("<outerBoundaryIs>"):].replace(',0.',',999.').replace(',0',';'))).rstrip('/').rstrip(';').replace(',999.',',0.')
                outer_block.append(block)
    elif (is3D==0):
        stripper = re.compile(r'[^\d.,-;]+')
        for item in text_all.split("</outerBoundaryIs>"):
            if "<outerBoundaryIs>" in item:
                block = (stripper.sub('', item[item.find("<outerBoundaryIs>")+
                         len("<outerBoundaryIs>"):].replace(' ',';'))).lstrip(';').rstrip('/').rstrip(';').rstrip('/').rstrip(';')
                outer_block.append(block)
    text_all = None
    
    outer = np.array([np.array([[float(v6) for v6 in v5] for v5 in v4]) for v4 in 
                     [[v3.split(',') for v3 in v2] for v2 in 
                      [v.split(';') for v in outer_block]]])
    outer_block = None
    
    if np.array([extentW,extentS,extentE,extentN]).all():
        extentWS = np.array([extentW,extentS])
        extentEN = np.array([extentE,extentN])
        
        WS = np.array([np.min(v1,axis=0) for v1 in outer])
        EN = np.array([np.max(v1,axis=0) for v1 in outer])
        
        isExtent = np.hstack((WS>extentWS,EN<extentEN)).all(axis=1)
        outer = np.extract(isExtent, outer)
    
    polygons = [Polygon(v[:,0], v[:,1]) for v in outer]
    return polygons

cs_prec = 0.004 # m

run_start = time.time()

#%%
# Shelved resumes
#shelveitems = ['demclippedPath',
#               'latm','lonm',
#               'isBuilding','buildingsPathList',
#               'clipW','clipS','clipE','clipN',
#               'isNLCD','nlcdPath','nlcdclippedPath',
#               'cnI','cnJ',
#               'Im','Jm',
#               'H1m','H2m','ANGm',
#               'outPath',
#               'cn_latm','cn_lonm',
#               'tmpPath',
#               'cs']

shelvename='out/shelve'
my_shelf = shelve.open(shelvename)
for key in my_shelf:
    try:
        globals()[key]=my_shelf[key]
    except:
        pass
my_shelf.close()

#%% Split by I
qrt = int(cnI/4)
mid = int(cnI/2)

latm1 = latm[:mid,:]
latm2 = latm[mid:,:]
lonm1 = lonm[:mid,:]
lonm2 = lonm[mid:,:]

latm_q1 = latm[:qrt,:]
latm_q2 = latm[qrt:qrt*2,:]
latm_q3 = latm[qrt*2:qrt*3,:]
latm_q4 = latm[qrt*3:,:]

lonm_q1 = lonm[:qrt,:]
lonm_q2 = lonm[qrt:qrt*2,:]
lonm_q3 = lonm[qrt*2:qrt*3,:]
lonm_q4 = lonm[qrt*3:,:]

#%% Depth
def griddata_depth(lonm_s,latm_s):
    demsplitPath = 'tmp/demsplitPath.tif'
#    splitMargin = cs*.00005 # 5 times cell size in meters
#    splitW = np.nanmin(lonm_s.ravel())-splitMargin
#    splitS = np.nanmin(latm_s.ravel())-splitMargin
#    splitE = np.nanmax(lonm_s.ravel())+splitMargin
#    splitN = np.nanmax(latm_s.ravel())+splitMargin
    splitW = np.nanmin(lonm_s.ravel())
    splitS = np.nanmin(latm_s.ravel())
    splitE = np.nanmax(lonm_s.ravel())
    splitN = np.nanmax(latm_s.ravel())
    splitMargin_WE = (splitE-splitW)*.1
    splitMargin_SN = (splitN-splitS)*.1
#    print(splitMargin,splitW,splitE,splitS,splitN)
    call(['gdalwarp', 
          '-te', '{:f}'.format(splitW-splitMargin_WE), '{:f}'.format(splitS-splitMargin_SN), 
          '{:f}'.format(splitE+splitMargin_WE), '{:f}'.format(splitN+splitMargin_SN), 
          '-overwrite',
          demclippedPath, demsplitPath])
    
    #
    print('Extracting depths from DEM...')
    bandNum1 = 1
    DEM = gdal.Open(demsplitPath, GA_ReadOnly )
    band1 = DEM.GetRasterBand(bandNum1)
    
    geotransform = DEM.GetGeoTransform()
    x_ul = geotransform[0]
    y_ul = geotransform[3]
    x_size = geotransform[1]
    y_size = geotransform[5]
    print('DEM cellsize: {xSize:f} x {ySize:f}'.format(xSize=x_size,ySize=y_size))
    
    data_raw = BandReadAsArray(band1)
    (y_cell,x_cell) = data_raw.shape
    xv, yv = meshgrid(range(x_cell), range(y_cell), indexing='xy')
    x_coor = xv * x_size + x_ul + (x_size*.5)
    y_coor = yv * y_size + y_ul + (y_size*.5)
    
    mask_domain = (data_raw>-9999)*(data_raw<9999)
    data = np.copy(data_raw).astype(float)
    data[~mask_domain] = np.nan
    
    band1 = None
    DEM = None
    data_raw = None
    xv = None
    yv = None
    
    # Split griddata scheme
    distm_y,distm_x = latlonlen(y_coor)
    x_coor_by_distm_x = np.ravel(x_coor*distm_x)
    y_coor_by_distm_y = np.ravel(y_coor*distm_y)
    data_ravel = np.ravel(data)
    #
    distm_lat,distm_lon = latlonlen(latm_s)
    valm = griddata((x_coor_by_distm_x,y_coor_by_distm_y), 
                      data_ravel, (np.ravel(lonm_s*distm_lon),
                      np.ravel(latm_s*distm_lat)), method='linear')
    valm = -valm.reshape(lonm_s.shape)
    return valm

depthm1 = griddata_depth(lonm_q1,latm_q1)
depthm2 = griddata_depth(lonm_q2,latm_q2)
depthm3 = griddata_depth(lonm_q3,latm_q3)
depthm4 = griddata_depth(lonm_q4,latm_q4)

depthm = np.concatenate((depthm1,depthm2,depthm3,depthm4), axis=0)

#depthm1 = None
#depthm2 = None
#depthm3 = None
#depthm4 = None

#%%
datumm = np.zeros(lonm.shape)

#%% Buildings
if isBuilding:
    print("Importing buildings...")
    for buildingsPath in buildingsPathList:
        polygons = kml2polygon(buildingsPath,extentW=clipW,extentS=clipS,
                               extentE=clipE,extentN=clipN)
        bad_building = 0
        for v in polygons:
            building_polygon = v.is_inside(lonm,latm)>0
            if (building_polygon.sum()/lonm.size)<.2:
                depthm[building_polygon] = np.nan
            else:
                bad_building+=1
                print('Bad building shape #{nBad:d}...'.format(nBad=bad_building))
        print("Imported from {buildingsPath:s}: {nBuilding:d} buildings.".format(buildingsPath=buildingsPath,nBuilding=len(polygons)))

#%% NLCD
if isNLCD:
    call(['gdalwarp', '-q', 
          '-te', '{:f}'.format(clipW), '{:f}'.format(clipS), 
          '{:f}'.format(clipE), '{:f}'.format(clipN), 
          nlcdPath, nlcdclippedPath])
    
    print('Extracting NLCD classes from raster...')
    
    bandNum1 = 1
    DEM = gdal.Open(nlcdclippedPath, GA_ReadOnly )
    band1 = DEM.GetRasterBand(bandNum1)
    
    geotransform = DEM.GetGeoTransform()
    x_ul = geotransform[0]
    y_ul = geotransform[3]
    x_size = geotransform[1]
    y_size = geotransform[5]
    print('NLCD raster cellsize: {xSize:f} x {ySize:f}'.format(xSize=x_size,ySize=y_size))
    
    data_raw = BandReadAsArray(band1)
    (y_cell,x_cell) = data_raw.shape
    xv, yv = meshgrid(range(x_cell), range(y_cell), indexing='xy')
    x_coor = xv * x_size + x_ul + (x_size*.5)
    y_coor = yv * y_size + y_ul + (y_size*.5)
    
    data = np.copy(data_raw).astype(float)
    
    band1 = None
    DEM = None
    
    # Split griddata scheme
    distm_y,distm_x = latlonlen(y_coor)
    x_coor_by_distm_x = np.ravel(x_coor*distm_x)
    y_coor_by_distm_y = np.ravel(y_coor*distm_y)
    data_ravel = np.ravel(data)
    
    def griddata_nlcd(lonm,latm):
        distm_lat,distm_lon = latlonlen(latm)
        valm = griddata((x_coor_by_distm_x,y_coor_by_distm_y), 
                          data_ravel, (np.ravel(lonm*distm_lon),
                          np.ravel(latm*distm_lat)), method='nearest')
        valm = valm.reshape(lonm.shape)
        return valm
    
    nlcdm1 = griddata_nlcd(lonm1,latm1)
    nlcdm2 = griddata_nlcd(lonm2,latm2)
    nlcdm = np.concatenate((nlcdm1, nlcdm2), axis=0)
    nlcdm[np.isnan(depthm)] = np.nan
    
    data_raw = None
    data = None
    x_coor = None
    y_coor = None
    xv = None
    yv = None
    distm_y = None
    distm_x = None
    x_coor_by_distm_x = None
    y_coor_by_distm_y = None
    data_ravel = None
    nlcdm1 = None
    nlcdm2 = None
    x_ul = None
    y_ul = None
    x_size = None
    y_size = None
    
    # NLCD to Manning's
    LC = pd.read_csv('templates/nlcd_table.csv')
    LC_match = list(zip(LC.NLCD.values,LC.Manning.values))
    LC_dict = dict(zip(LC.NLCD.values,LC.Name.values))
    
    manm = np.ones(nlcdm.shape)*.02 # Conservative base value
    for v in LC_match:
        manm[nlcdm==v[0]] = round(v[1],3)
    
    BFRIC_base = 0.0025

#%% Output
print('Write to output...')

# Write to model_grid_hor
s = []
s += "Horizontal Segmentations\n"
s += "{nI:5d}{nJ:5d}".format(nI=cnI,nJ=cnJ)
for j in range(1,cnJ-1):
    for i in range(1,cnI-1):
        if ~np.isnan(depthm[i][j]):
            s += "\n{I:5d}{J:5d}{H1:10.2f}{H2:10.2f}{depth:10.3f}{ang:10.2f}{lat:10.6f}{lon:10.6f}{datum:5.1f}".format(I=Im[i][j],J=Jm[i][j],H1=H1m[i][j],H2=H2m[i][j],depth=depthm[i][j],ang=ANGm[i][j],lat=latm[i][j],lon=lonm[i][j],datum=datumm[i][j])  
with open(outPath+'model_grid_hor', 'w') as f:
    f.writelines(s)

# Write to corner_loc
s = []
for j in range(cnJ+1):
    for i in range(cnI+1):
        s += "{I:5d}{J:5d}{lon:12.6f}{lat:12.6f}{mask:5d}\n".format(I=i+1,J=j+1,lat=cn_latm[i][j],lon=cn_lonm[i][j],mask=1)  
with open(outPath+'corner_loc', 'w') as f:
    f.writelines(s)

if not isNLCD:
    # Write model_grid to csv
    s = []
    s += "I,J,H1,H2,depth,ang,lat,lon,datum"
    for j in range(1,cnJ-1):
        for i in range(1,cnI-1):
            if ~np.isnan(depthm[i][j]):
                s += "\n{I:d},{J:d},{H1:.2f},{H2:.2f},{depth:.3f},{ang:.2f},{lat:.6f},{lon:.6f},{datum:.1f}".format(I=Im[i][j],J=Jm[i][j],H1=H1m[i][j],H2=H2m[i][j],depth=depthm[i][j],ang=ANGm[i][j],lat=latm[i][j],lon=lonm[i][j],datum=datumm[i][j])  
    with open(outPath+'model_grid.csv', 'w') as f:
        f.writelines(s)
else:    
    # Write to bfric2d.inp
    s = []
    s += "NVARBF    BFRIC\n"
    s += "   -1{base:10.5f}\n".format(base=BFRIC_base)
    s += "    I    J     VARBF"
    for j in range(cnJ):
        for i in range(cnI):
            s += "\n{I:5d}{J:5d}{Man:10.5f}".format(I=i+1,J=j+1,Man=manm[i][j])  
    with open(outPath+'bfric2d.inp', 'w') as f:
        f.writelines(s)
    
    # Write model_grid and NLCD/Manning's to csv
    s = []
    s += "I,J,H1,H2,depth,ang,lat,lon,datum,NLCD,Mannings,Land"
    for j in range(1,cnJ-1):
        for i in range(1,cnI-1):
            if ~np.isnan(depthm[i][j]):
                s += "\n{I:d},{J:d},{H1:.2f},{H2:.2f},{depth:.3f},{ang:.2f},{lat:.6f},{lon:.6f},{datum:.1f},{NLCD:.0f},{Mannings:.3f},{Land:s}".format(I=Im[i][j],J=Jm[i][j],H1=H1m[i][j],H2=H2m[i][j],depth=depthm[i][j],ang=ANGm[i][j],lat=latm[i][j],lon=lonm[i][j],datum=datumm[i][j],NLCD=nlcdm[i][j],Mannings=manm[i][j],Land=LC_dict[int(nlcdm[i][j])])  
    with open(outPath+'model_grid.csv', 'w') as f:
        f.writelines(s)

# Save to binary
np.savez('out/bin.npz', 
         cnI=cnI,cnJ=cnJ,Im=Im,Jm=Jm,H1m=H1m,H2m=H2m,depthm=depthm,
         ANGm=ANGm,latm=latm,lonm=lonm,datumm=datumm,nlcdm=nlcdm,manm=manm)

#%% Stats
stats_node = cnI*cnJ
stats_area = np.nansum((H1m*H2m).ravel())

stats_dt1 = np.nanmin((0.5*H1m/np.sqrt(9.80665*np.ceil(depthm+6))).ravel())
stats_dt2 = np.nanmin((0.5*H2m/np.sqrt(9.80665*np.ceil(depthm+6))).ravel())

stats_lon_max = np.nanmax(lonm.ravel())
stats_lon_min = np.nanmin(lonm.ravel())
stats_lat_max = np.nanmax(latm.ravel())
stats_lat_min = np.nanmin(latm.ravel())

stats_H1_mean = np.nanmean(H1m.ravel())
stats_H1_median = np.nanmedian(H1m.ravel())
stats_H1_max = np.nanmax(H1m.ravel())
stats_H1_min = np.nanmin(H1m.ravel())
stats_H2_mean = np.nanmean(H2m.ravel())
stats_H2_median = np.nanmedian(H2m.ravel())
stats_H2_max = np.nanmax(H2m.ravel())
stats_H2_min = np.nanmin(H2m.ravel())
stats_ANG_mean = np.nanmean(ANGm.ravel())
stats_ANG_median = np.nanmedian(ANGm.ravel())
stats_ANG_max = np.nanmax(ANGm.ravel())
stats_ANG_min = np.nanmin(ANGm.ravel())
stats_depth_mean = np.nanmean(depthm.ravel())
stats_depth_median = np.nanmedian(depthm.ravel())
stats_depth_max = np.nanmax(depthm.ravel())
stats_depth_min = np.nanmin(depthm.ravel())

# Write to stats.txt
s=[]
s+='Stats\n'
s+='Nodes: {:d} x {:d} = {:d}\n'.format(cnI,cnJ,stats_node)
s+='Extent: {:.6f}, {:.6f}, {:.6f}, {:.6f}\n'.format(stats_lon_min,stats_lat_min,stats_lon_max,stats_lat_max)
s+='Area: {:.2f} m^2\n'.format(stats_area)
s+='H1: mean({:.2f}), median({:.2f}), min({:.2f}), max({:.2f})\n'.format(stats_H1_mean,stats_H1_median,stats_H1_min,stats_H1_max)
s+='H2: mean({:.2f}), median({:.2f}), min({:.2f}), max({:.2f})\n'.format(stats_H2_mean,stats_H2_median,stats_H2_min,stats_H2_max)
s+='ANG: mean({:.2f}), median({:.2f}), min({:.2f}), max({:.2f})\n'.format(stats_ANG_mean,stats_ANG_median,stats_ANG_min,stats_ANG_max)
s+='Depth: mean({:.3f}), median({:.3f}), min({:.3f}), max({:.3f})\n'.format(stats_depth_mean,stats_depth_median,stats_depth_min,stats_depth_max)
s+='Min time step along I: {:.3f} s\n'.format(stats_dt1)
s+='Min time step along J: {:.3f} s\n'.format(stats_dt2)
with open(outPath+'stats.txt', 'w') as f:
    f.writelines(s)

#%%
#shutil.rmtree(tmpPath)
#status = 'Job completed'

run_end = time.time()
print(run_end-run_start)
print('Job completed successfully.\n')